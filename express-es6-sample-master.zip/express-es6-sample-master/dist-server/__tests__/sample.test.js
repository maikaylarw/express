"use strict";

it('it runs', function () {
  expect(1 + 1).toBe(2);
});